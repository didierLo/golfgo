'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useTranslations, useLocale } from 'next-intl'

interface Group       { id: string; name: string; color: string; role: 'owner' | 'member'; backgroundUrl: string | null }
interface CurrentUser { initials: string; name: string; email: string | null }

const FALLBACK_COLORS = ['#378ADD', '#EF9F27', '#7F77DD', '#1D9E75', '#D85A30', '#D4537E']

const Icons = {
  myEvents:      (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.4" /><path d="M8 5v3l2 2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>),
  scorecard:     (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><rect x="2" y="1" width="12" height="14" rx="2" stroke="currentColor" strokeWidth="1.4" /><path d="M5 5h6M5 8h6M5 11h4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>),
  teesheet:      (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><rect x="1" y="2" width="14" height="12" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M1 6h14" stroke="currentColor" strokeWidth="1.4"/><path d="M5 2v4M11 2v4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><circle cx="5" cy="10" r="1" fill="currentColor"/><circle cx="8" cy="10" r="1" fill="currentColor"/><circle cx="11" cy="10" r="1" fill="currentColor"/></svg>),
  participants:  (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><circle cx="5" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.4" /><path d="M1 13c0-2.76 2.24-5 4-5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /><circle cx="11" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.4" /><path d="M15 13c0-2.76-2.24-5-4-5H9c-1.76 0-4 2.24-4 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>),
  groups:        (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><circle cx="6" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.4" /><path d="M1 13c0-2.76 2.24-5 5-5a5 5 0 015 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /><circle cx="12" cy="5" r="2" stroke="currentColor" strokeWidth="1.4" /></svg>),
  events:        (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><rect x="1" y="4" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.4" /><path d="M5 4V3a1 1 0 012 0v1M9 4V3a1 1 0 012 0v1" stroke="currentColor" strokeWidth="1.4" /></svg>),
  invitations:   (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><rect x="1" y="3" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M1 5l7 5 7-5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>),
  flights:       (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M9 2a1 1 0 011 1v2.5l3 1.5v1.5l-3-1v2l1 .5V11l-2-.5L7 11v-1.5l1-.5v-2l-3 1V6.5l3-1.5V3a1 1 0 011-1z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"/></svg>),
  results:       (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M3 13V8M7 13V5M11 13V2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><circle cx="13" cy="2" r="1.5" fill="currentColor"/></svg>),
  stats:         (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M2 14h12M4 14V9M8 14V3M12 14V6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>),
  clubs:         (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M3 14V2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /><path d="M3 2l9 3-9 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  communications:(<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M14 2H2a1 1 0 00-1 1v8a1 1 0 001 1h3l3 3 3-3h3a1 1 0 001-1V3a1 1 0 00-1-1z" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/><path d="M4 6h8M4 9h5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>),
  settings:      (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="2.5" stroke="currentColor" strokeWidth="1.4" /><path d="M8 1v2M8 13v2M1 8h2M13 8h2M3.05 3.05l1.41 1.41M11.54 11.54l1.41 1.41M3.05 12.95l1.41-1.41M11.54 4.46l1.41-1.41" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>),
  chevronDown:   (<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  check:         (<svg width="13" height="13" viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  plus:          (<svg width="14" height="14" viewBox="0 0 12 12" fill="none"><path d="M6 2v8M2 6h8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>),
  user:          (<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5.5" r="2.5" stroke="white" strokeWidth="1.4" /><path d="M2.5 14c0-3.04 2.46-5.5 5.5-5.5s5.5 2.46 5.5 5.5" stroke="white" strokeWidth="1.4" strokeLinecap="round" /></svg>),
  back:          (<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>),
  payments:      (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><rect x="1" y="3" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M1 7h14" stroke="currentColor" strokeWidth="1.4"/><circle cx="5" cy="10.5" r="1" fill="currentColor"/></svg>),
  promotions:    (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M2 8.4V2.8A.8.8 0 012.8 2h5.6a.8.8 0 01.57.23l5 5a.8.8 0 010 1.14l-5.6 5.6a.8.8 0 01-1.14 0l-5-5A.8.8 0 012 8.4z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/><circle cx="5.2" cy="5.2" r="1" fill="currentColor"/></svg>),
  distance:      (<svg width="18" height="18" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="5.2" stroke="currentColor" strokeWidth="1.4"/><circle cx="8" cy="8" r="1.5" fill="currentColor"/><path d="M8 .8v2.4M8 12.8v2.4M.8 8h2.4M12.8 8h2.4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>),
  hamburger: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <rect x="3"  y="4.5"  width="3" height="3" rx="0.5" fill="currentColor" />
      <rect x="8"  y="5"    width="9" height="2" rx="1"   fill="currentColor" />
      <rect x="3"  y="8.5"  width="3" height="3" rx="0.5" fill="currentColor" />
      <rect x="8"  y="9"    width="9" height="2" rx="1"   fill="currentColor" />
      <rect x="3"  y="12.5" width="3" height="3" rx="0.5" fill="currentColor" />
      <rect x="8"  y="13"   width="9" height="2" rx="1"   fill="currentColor" />
    </svg>
  ),
}

function NavItem({ href, icon, label, active, muted, iconColor }: { href: string; icon: React.ReactNode; label: string; active: boolean; muted?: boolean; iconColor?: string }) {
  const t = useTranslations()
  return (
    <Link href={href} className={`group flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13.5px] font-semibold transition-all duration-150 ${active ? 'bg-[#185FA5] text-white shadow-sm shadow-blue-900/20' : muted ? 'text-slate-400 hover:text-slate-500 hover:bg-slate-100/60' : 'text-slate-900 hover:text-black hover:bg-slate-100/80'}`}>
      <span className="shrink-0 transition-transform duration-150 group-hover:scale-110" style={{ color: active ? 'white' : muted ? '#CBD5E1' : (iconColor ?? '#185FA5') }}>{icon}</span>
      <span className="flex-1 leading-none">{label}</span>
      {muted && <span className="text-[9px] text-slate-400 font-normal tracking-wide uppercase">{t('nav.soon')}</span>}
    </Link>
  )
}

function NavIconItem({ href, icon, label, active, muted, iconColor }: { href: string; icon: React.ReactNode; label: string; active: boolean; muted?: boolean; iconColor?: string }) {
  const t = useTranslations()
  return (
    <Link href={href} title={label} className={`group relative flex items-center justify-center w-10 h-10 rounded-xl transition-all duration-150 ${active ? 'bg-[#185FA5] text-white shadow-sm shadow-blue-900/20' : muted ? 'text-slate-300 hover:text-slate-400 hover:bg-slate-100/60' : 'hover:bg-blue-50'}`}>
      <span className="transition-transform duration-150 group-hover:scale-110" style={{ color: active ? 'white' : muted ? '#CBD5E1' : (iconColor ?? '#185FA5') }}>{icon}</span>
      <span className="pointer-events-none absolute left-full ml-2 z-50 whitespace-nowrap rounded-lg bg-slate-900 text-white text-[11px] font-semibold px-2.5 py-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-150 shadow-lg">
        {label}{muted && <span className="ml-1 text-slate-400">({t('nav.soon')})</span>}
      </span>
    </Link>
  )
}

function SidebarSection({ label, emoji, children }: { label: string; emoji?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-0.5">
      <p className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase tracking-[0.12em] px-3 mb-1.5 mt-1">
        {emoji && <span className="text-[11px]">{emoji}</span>}{label}
      </p>
      {children}
    </div>
  )
}

function GroupDot({ color, size = 8 }: { color: string; size?: number }) {
  return <span className="rounded-full shrink-0 ring-2 ring-white" style={{ width: size, height: size, background: color, display: 'inline-block' }} />
}

const ORGANISER_SEGMENTS = [
  '/events/', '/invitations', '/flights', '/results', '/participants',
  '/teesheet', '/scorecards', '/leaderboard', '/communications',
  '/members', '/constraints', '/edit', '/scorecard', '/admin/clubs', '/partners',
]
const supabase = createClient()
export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname                                  = usePathname()
  const router                                    = useRouter()
  const t                                         = useTranslations()
  const locale                                    = useLocale()
  const [groups,            setGroups]            = useState<Group[]>([])
  const [activeGroup,       setActiveGroup]       = useState<Group | null>(null)
  const [currentUser,       setCurrentUser]       = useState<CurrentUser | null>(null)
  const [currentPlayerId,   setCurrentPlayerId]   = useState<string | null>(null)
  const [loading,           setLoading]           = useState(true)
  const [drawerOpen,        setDrawerOpen]        = useState(false)
  const [avatarMenuOpen,    setAvatarMenuOpen]    = useState(false)
  const [nearestEventId,    setNearestEventId]    = useState<string | null>(null)
  const [pillMenuOpen,      setPillMenuOpen]      = useState(false)
  const [deleteModalOpen, setDeleteModalOpen]     = useState(false)
  const [deleteLoading,   setDeleteLoading]       = useState(false)
  const [deleteConfirmed, setDeleteConfirmed]     = useState(false)
  const pillRef                                   = useRef<HTMLDivElement>(null)
  const avatarRef                                 = useRef<HTMLDivElement>(null)

  const showBack = ORGANISER_SEGMENTS.some(s => pathname.includes(s))

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (avatarRef.current   && !avatarRef.current.contains(e.target as Node))   setAvatarMenuOpen(false)
      if (pillRef.current  && !pillRef.current.contains(e.target as Node))  setPillMenuOpen(false)
    }
    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  useEffect(() => {
    async function loadData() {
      try {
        const { data: { session } } = await supabase.auth.getSession()
        const user = session?.user
        if (!user) { setLoading(false); return }

        let { data: playerData, error: playerError } = await supabase.from('players').select('id, first_name, surname').eq('user_id', user.id).single()

          if ((playerError || !playerData)) {
            // Filet de sécurité général : peu importe comment la session a été
            // créée (login classique, reset password, session déjà existante
            // au chargement), on tente ici le rattachement players.user_id
            // s'il n'a pas encore eu lieu, puis on retente une seule fois.
            try {
              const res = await fetch('/api/link-player', { method: 'POST' })
              const result = await res.json().catch(() => null)
              if (result?.linked) {
                const retry = await supabase.from('players').select('id, first_name, surname').eq('user_id', user.id).single()
                playerData  = retry.data
                playerError = retry.error
              }
            } catch (linkError) {
              console.error('[AppLayout] link-player retry failed:', linkError)
            }
          }

        if (playerError || !playerData) { setLoading(false); return }
        const initials = ((playerData.first_name?.[0] ?? '') + (playerData.surname?.[0] ?? '')).toUpperCase()
              setCurrentUser({ initials, name: `${playerData.first_name} ${playerData.surname}`, email: user.email ?? null })
        setCurrentPlayerId(playerData.id)
        const { data, error } = await supabase.from('groups_players').select(`role, groups(id, name, color, background_url)`).eq('player_id', playerData.id)
        if (error) { setLoading(false); return }
        const fetchedGroups: Group[] = (data ?? []).filter((row: any) => row.groups).map((row: any, index: number) => ({
          id: row.groups.id, name: row.groups.name,
          color: row.groups.color ?? FALLBACK_COLORS[index % FALLBACK_COLORS.length],
          role: row.role as 'owner' | 'member',
          backgroundUrl: row.groups.background_url ?? null,
        }))
        setGroups(fetchedGroups)
        const urlGroupId = pathname.match(/\/groups\/([^/]+)/)?.[1]
        const lastGroupId = localStorage.getItem('golfgo-last-group')
        const determined  = fetchedGroups.find(g => g.id === urlGroupId)
                        ?? fetchedGroups.find(g => g.id === lastGroupId)
                        ?? fetchedGroups[0]
                        ?? null
        setActiveGroup(determined)
      } catch (e) { console.error('AppLayout error:', e) }
      finally { setLoading(false) }
    }
    loadData()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (groups.length === 0) return
    const urlGroupId = pathname.match(/\/groups\/([^/]+)/)?.[1]
   
    if (urlGroupId) { const match = groups.find(g => g.id === urlGroupId); if (match) {
     setActiveGroup(match)
     localStorage.setItem('golfgo-last-group', match.id)
    } }
  }, [pathname, groups])

  useEffect(() => {
  const groupId = activeGroup?.id
  if (!groupId) return

  // D'abord vérifier le localStorage (synchrone, immédiat)
  const retained = localStorage.getItem(`golfgo-active-event-${groupId}`)
  if (retained) { setNearestEventId(retained); return }

  // Sinon chercher en base
  async function loadNearest() {
    const now = new Date().toISOString()
    const { data: future } = await supabase.from('events').select('id')
      .eq('group_id', groupId).gte('starts_at', now)
      .order('starts_at', { ascending: true }).limit(1)
    if (future?.[0]) {
      setNearestEventId(future[0].id)
      localStorage.setItem(`golfgo-active-event-${groupId}`, future[0].id)
      return
    }
    const { data: past } = await supabase.from('events').select('id')
      .eq('group_id', groupId).lt('starts_at', now)
      .order('starts_at', { ascending: false }).limit(1)
    const id = past?.[0]?.id ?? null
    setNearestEventId(id)
    if (id) localStorage.setItem(`golfgo-active-event-${groupId}`, id)
  }
  loadNearest()
}, [activeGroup?.id, pathname])

  const isActive       = (href: string) => pathname === href || pathname.startsWith(href + '/')
  const isGroupsActive = pathname === '/groups' || pathname === '/groups/add'
  const gid            = activeGroup?.id
  const eid            = nearestEventId
  const isAnyOwner     = groups.some(g => g.role === 'owner')

  const eventsHref         = gid ? `/groups/${gid}/events`         : '/groups'
  const communicationsHref = gid ? `/groups/${gid}/communications` : '/groups'
  const groupsHref         = '/groups'
  const clubsHref          = '/admin/clubs'
  const participantsHref = gid && eid ? `/groups/${gid}/events/${eid}/participants` : (gid ? `/groups/${gid}/no-event` : null)
  const teesheetHref     = gid && eid ? `/groups/${gid}/events/${eid}/teesheet`     : (gid ? `/groups/${gid}/no-event` : null)
  const invitationsHref  = gid        ? `/groups/${gid}/invitations`                : null

  const paymentsHref = gid && eid ? `/groups/${gid}/events/${eid}/payments` : (gid ? `/groups/${gid}/no-event` : null)
  const flightsHref      = gid && eid ? `/groups/${gid}/events/${eid}/flights`      : (gid ? `/groups/${gid}/no-event` : null)
  const resultsHref      = gid && eid ? `/groups/${gid}/events/${eid}/results`      : (gid ? `/groups/${gid}/no-event` : null)
  const statsHref        = gid ? `/groups/${gid}/stats` : null

  const eventsListActive = !isAnyOwner ? false : !!gid && (pathname === `/groups/${gid}/events` || pathname === `/groups/${gid}/events/add`)

  const organiserDrawerItems = [
      { href: groupsHref,                   icon: Icons.groups,         label: t('nav.groups'),         color: '#7F77DD', active: isGroupsActive },
      { href: eventsHref,                   icon: Icons.events,         label: t('nav.events'),         sublabel: activeGroup?.name ?? null, color: '#185FA5', active: eventsListActive },
      { href: invitationsHref ?? '/groups', icon: Icons.invitations,    label: t('nav.invitations'),    color: '#0C447C', active: !!invitationsHref && isActive(invitationsHref) },
      { href: paymentsHref ?? '/groups',    icon: Icons.payments,       label: t('nav.payments'),       color: '#3B6D11', active: !!paymentsHref && isActive(paymentsHref ?? '') },  // ← ici
      { href: flightsHref ?? '/groups',     icon: Icons.flights,        label: t('nav.flights'),        color: '#EF9F27', active: !!flightsHref && isActive(flightsHref) },
      { href: resultsHref ?? '/groups',     icon: Icons.results,        label: t('nav.results'),        color: '#3B6D11', active: !!resultsHref && isActive(resultsHref) },
      { href: clubsHref,                    icon: Icons.clubs,          label: t('nav.clubs'),          color: '#EF9F27', active: isAnyOwner && isActive('/admin/clubs') },
      { href: communicationsHref,           icon: Icons.communications, label: t('nav.communications'), color: '#D4537E', active: !!gid && isActive(`/groups/${gid}/communications`) },
      { href: statsHref ?? '/groups',       icon: Icons.stats,          label: t('nav.stats'),          color: '#7F77DD', active: !!statsHref && isActive(statsHref) },
    ]

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'transparent' }}>
     <div className="fixed inset-0 -z-10 overflow-hidden">
  {/* Photo du groupe actif si l'organisateur en a choisi une, sinon l'image par défaut de GolfGo.
      <img> plutôt que next/image : la photo peut venir du stockage Supabase (un autre domaine),
      que next/image refuserait sans configuration supplémentaire dans next.config.ts. */}
  {/* eslint-disable-next-line @next/next/no-img-element */}
  <img
    src={activeGroup?.backgroundUrl || '/golf-bg.jpg'}
    alt=""
    style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% center' }}
  />
</div>

      {/* TOPBAR */}
      <header className="h-[56px] flex items-center shrink-0 z-30 shadow-md shadow-blue-900/20 overflow-visible"
        style={{ background: 'rgba(24, 95, 165, 0.85)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}>
        <div className="max-w-[1280px] w-full mx-auto flex items-center overflow-visible" style={{ scrollbarWidth: 'none' }}>
          <div className="flex items-center shrink-0 w-[60px] sm:w-[60px] lg:w-[220px]">
            <Link href="/my-events" className="flex items-center gap-2.5 select-none px-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logo/GG_Favicon.png" alt="" className="h-[30px] w-[30px] object-contain rounded-lg shrink-0" />
              <span className="hidden lg:flex items-baseline leading-none">
                <span className="text-[18px] font-black text-white tracking-tight">Golf</span>
                <span className="text-[18px] font-black tracking-tight" style={{ color: '#4CAF1A' }}>Go</span>
              </span>
            </Link>
          </div>
          <div className="w-px h-full bg-white/30 shrink-0 self-stretch" />
          <div className="flex items-center gap-3 flex-1 px-4">

           {showBack && (
              <button onClick={() => router.back()}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[12px] font-semibold text-white/80 hover:text-white hover:bg-white/10 transition-all shrink-0">
                {Icons.back}
                <span>{t('nav.back')}</span>
              </button>
            )}

            {loading ? (
              <div className="h-8 w-48 rounded-full bg-white/15 animate-pulse" />
                      ) : activeGroup ? (
                <div className="relative shrink-0" ref={pillRef}>
                  <button
                    onClick={() => {
                    setPillMenuOpen(v => !v)
                  }}
                    className="flex items-center gap-2.5 bg-white/15 border border-white/20 rounded-full pl-2.5 pr-3 py-1.5 hover:bg-white/25 transition-colors">
                    <GroupDot color={activeGroup.color} size={9} />
                    <span className="text-[13px] font-semibold text-white leading-none max-w-[140px] sm:max-w-[200px] truncate">
                      {activeGroup.name}
                    </span>
                    <span className="text-white/60 ml-0.5">{Icons.chevronDown}</span>
                  </button>

                  {pillMenuOpen && (
                    <div className="absolute top-[calc(100%+8px)] left-0 w-56 bg-white border border-slate-200/80 rounded-2xl shadow-xl shadow-slate-900/10 py-2 z-[9999] overflow-hidden">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-4 py-2">
                        {t('nav.myGroups')}
                      </p>
                      {groups.map(g => (
                        <button
                          key={g.id}
                            onClick={async () => {
                              localStorage.setItem('golfgo-last-group', g.id)
                              setPillMenuOpen(false)

                              const lastSegment = pathname.split('/').pop()
                              const pagesWithEvent = ['participants', 'flights', 'results', 'teesheet', 'scorecards', 'history']
                             
                              let targetEventId = nearestEventId
                              
                              if (pagesWithEvent.includes(lastSegment ?? '')) {
                                const now = new Date().toISOString()
                                const { data } = await supabase.from('events').select('id')
                                  .eq('group_id', g.id).gte('starts_at', now)
                                  .order('starts_at', { ascending: true }).limit(1)
                                targetEventId = data?.[0]?.id ?? nearestEventId
                              }
                              
                            if (pathname.includes('/my-events')) {
                              router.push(`/groups/${g.id}/events`)
                            } else if (!pathname.includes('/groups/')) {
                              setActiveGroup(g)
                              window.location.href = pathname  // recharge complète → init() relu
                              return                           // ← le return évite le router.refresh() final
                            } else if (pathname.match(/\/groups\/?$/) || pathname.includes('/groups/add')) {
                              router.refresh()
                              return
                            } else if (pagesWithEvent.includes(lastSegment ?? '') && targetEventId) {
                              const flightsPrefix = lastSegment === 'history' ? 'flights/' : ''
                              router.push(`/groups/${g.id}/events/${targetEventId}/${flightsPrefix}${lastSegment}`)
                            } else {
                              const afterGroupId = pathname.match(/\/groups\/[^/]+\/(.+)/)?.[1]
                              const newPath = afterGroupId
                                ? `/groups/${g.id}/${afterGroupId.replace(/[0-9a-f-]{36}/g, '').replace(/\/\//g, '/')}`
                                : `/groups/${g.id}/events`
                              router.push(newPath)
                            }
                            router.refresh()
                            }}
                                                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 transition-colors">
                          <GroupDot color={g.color} size={8} />
                          <span className="flex-1 text-left text-[13px] font-medium text-slate-700 truncate">{g.name}</span>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                            style={{
                              background: g.role === 'owner' ? '#EAF3DE' : '#EBF3FC',
                              color:      g.role === 'owner' ? '#3B6D11' : '#0C447C',
                            }}>
                            {g.role === 'owner' ? t('nav.admin') : t('nav.member')}
                          </span>
                          {activeGroup.id === g.id && (
                            <span className="text-[#185FA5]">{Icons.check}</span>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
              <Link href="/groups/add" className="flex items-center gap-2 bg-white/10 hover:bg-white/15 border border-white/20 border-dashed rounded-full px-3 py-1.5 transition-colors">
                <span className="text-white/50">{Icons.plus}</span>
                <span className="text-[13px] text-white/60 font-medium leading-none">{t('nav.createGroup')}</span>
              </Link>
            )}

            <div className="flex-1" />

            {currentUser ? (
              <div className="relative shrink-0" ref={avatarRef}>
                <button onClick={() => setAvatarMenuOpen(v => !v)} title={currentUser.name}
                  className="w-[34px] h-[34px] rounded-full bg-[#4CAF1A] flex items-center justify-center text-[12px] font-black text-white select-none ring-2 ring-white/30 hover:ring-white/60 transition-all cursor-pointer">
                  {currentUser.initials}
                </button>
                {avatarMenuOpen && (
                  <div className="fixed top-[56px] right-4 w-52 bg-white border border-slate-200/80 rounded-2xl shadow-xl shadow-slate-900/10 py-2 z-[9999] overflow-hidden">
                    <div className="px-4 py-2.5 border-b border-slate-100">
                      <p className="text-[12px] font-bold text-slate-800 truncate">{currentUser.name}</p>
                    </div>
                   <Link href={currentPlayerId ? `/players/${currentPlayerId}/edit` : '/settings'}
                      onClick={() => setAvatarMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 transition-colors">
                      <span className="text-slate-400">{Icons.user}</span>
                      <span className="text-[13px] text-slate-700 font-medium">{t('nav.myProfile')}</span>
                    </Link>
                    {currentUser.email?.toLowerCase() === 'didier.lozet@gmail.com' && (
                      <Link href="/admin/health"
                        onClick={() => setAvatarMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 transition-colors">
                        <span className="text-slate-400">🩺</span>
                        <span className="text-[13px] text-slate-700 font-medium">Santé du système</span>
                      </Link>
                    )}
                    <div className="px-4 py-2.5">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{t('nav.language')}</p>
                      <div className="flex gap-1">
                        {[
                          { code: 'fr', label: '🇫🇷 FR' },
                          { code: 'en', label: '🇬🇧 EN' },
                          { code: 'nl', label: '🇳🇱 NL' },
                          { code: 'de', label: '🇩🇪 DE' },
                          { code: 'es', label: '🇪🇸 ES' },
                        ].map(lang => (
                          <button key={lang.code}
                            onClick={() => {
                              const segments = pathname.split('/')
                              segments[1] = lang.code
                              window.location.href = segments.join('/')
                              setAvatarMenuOpen(false)
                            }}
                            className={`text-[11px] font-semibold px-2 py-1 rounded-lg transition-colors ${
                              locale === lang.code
                                ? 'bg-[#185FA5] text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}>
                            {lang.label}
                          </button>
                        ))}
                      </div>
                    </div>
                      <button
                        onClick={() => { setAvatarMenuOpen(false); setDeleteModalOpen(true) }}
                        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-red-50 transition-colors">
                        <span className="text-red-300">
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M2 4h12M5 4V2h6v2M6 7v5M10 7v5M3 4l1 9a1 1 0 001 1h6a1 1 0 001-1l1-9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        </span>
                        <span className="text-[13px] text-red-400 font-medium">{t('nav.deleteAccount')}</span>
                      </button>
                   <a href="mailto:info@golfgo.be"
                    onClick={() => setAvatarMenuOpen(false)}
                    className="flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 transition-colors">
                    <span className="text-slate-400">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <rect x="1" y="3" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/>
                        <path d="M1 5l7 5 7-5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </span>
                    <span className="text-[13px] text-slate-700 font-medium">{t('nav.support')}</span>
                  </a>
                  <div className="mx-3 my-1 h-px bg-slate-100" />
                  <button onClick={async () => { await supabase.auth.signOut(); window.location.href = '/login' }}
                      className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-red-50 transition-colors">
                      <span className="text-red-400">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M6 14H3a1 1 0 01-1-1V3a1 1 0 011-1h3M10 11l3-3-3-3M13 8H6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </span>
                      <span className="text-[13px] text-red-500 font-semibold">{t('nav.signOut')}</span>
                    </button>
                  <div className="flex gap-3 px-4 py-2.5 border-t border-slate-100 mt-1">
                    <Link href={`/${locale}/legal/cgu`} onClick={() => setAvatarMenuOpen(false)}
                      className="text-[11px] text-slate-400 hover:text-slate-600 transition-colors">
                      {t('nav.cgu')}
                    </Link>
                    <Link href={`/${locale}/legal/privacy`} onClick={() => setAvatarMenuOpen(false)}
                      className="text-[11px] text-slate-400 hover:text-slate-600 transition-colors">
                      {t('nav.privacy')}
                    </Link>
                  </div>

                  </div>
                )}
              </div>
            ) : (
              <Link href="/login" className="w-[34px] h-[34px] rounded-full bg-white/10 border border-white/20 flex items-center justify-center hover:bg-white/20 transition-colors shrink-0">
                {Icons.user}
              </Link>
            )}
          </div>
        </div>
      </header>

      <div className="flex flex-1 max-w-[1280px] w-full mx-auto">

        

        {/* Sidebar desktop */}
        <aside className="hidden lg:flex w-[220px] shrink-0 flex-col py-6 px-3 gap-1 border-r border-white/50"
          style={{ background: 'rgba(255,255,255,0.65)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}>
          <SidebarSection label={t('nav.play')} emoji="⛳">
            <NavItem href="/my-events"                    icon={Icons.myEvents}     iconColor="#185FA5" label={t('nav.myEvents')}    active={isActive('/my-events')} />
            <NavItem href={participantsHref ?? '/groups'} icon={Icons.participants} iconColor="#7F77DD" label={t('nav.participants')} active={!!participantsHref && isActive(participantsHref)} />
            <NavItem href={teesheetHref ?? '/groups'}     icon={Icons.teesheet}     iconColor="#1D9E75" label={t('nav.teesheet')}     active={!!teesheetHref && isActive(teesheetHref)} />
            <NavItem href="/scorecard"                    icon={Icons.scorecard}    iconColor="#D85A30" label={t('nav.scorecard')}    active={isActive('/scorecard')} />
            <NavItem href="/promotions"                   icon={Icons.promotions}   iconColor="#D4537E" label={t('nav.promotions')}   active={isActive('/promotions')} />
            <NavItem href="/distance"                      icon={Icons.distance}       iconColor="#1D9E75" label={t('nav.distance')}    active={isActive('/distance')} />
          </SidebarSection>


          <div className="mx-2 my-3 h-px bg-slate-100" />
          <SidebarSection label={t('nav.organiser')} emoji="🏆">
            <NavItem href={groupsHref}                    icon={Icons.groups}         iconColor="#7F77DD" label={t('nav.groups')}         active={isGroupsActive} />
            <NavItem href={eventsHref}                    icon={Icons.events}         iconColor="#185FA5" label={t('nav.events')}         active={eventsListActive} />
            <NavItem href={invitationsHref ?? '/groups'}  icon={Icons.invitations}    iconColor="#0C447C" label={t('nav.invitations')}    active={!!invitationsHref && isActive(invitationsHref)} />
            <NavItem href={paymentsHref ?? '/groups'} icon={Icons.payments} iconColor="#3B6D11" label={t('nav.payments')} active={!!paymentsHref && isActive(paymentsHref)} />
            <NavItem href={flightsHref ?? '/groups'}      icon={Icons.flights}        iconColor="#EF9F27" label={t('nav.flights')}        active={!!flightsHref && isActive(flightsHref)} />
            <NavItem href={resultsHref ?? '/groups'}      icon={Icons.results}        iconColor="#3B6D11" label={t('nav.results')}        active={!!resultsHref && isActive(resultsHref)} />
            <NavItem href={clubsHref}                     icon={Icons.clubs}          iconColor="#D4537E" label={t('nav.clubs')}          active={isAnyOwner && isActive('/admin/clubs')} />
            <NavItem href={communicationsHref}            icon={Icons.communications} iconColor="#D4537E" label={t('nav.communications')} active={!!gid && isActive(`/groups/${gid}/communications`)} />
            <NavItem href={statsHref ?? '/groups'}        icon={Icons.stats}          iconColor="#7F77DD" label={t('nav.stats')}          active={!!statsHref && isActive(statsHref)} />
          </SidebarSection>

          <div className="mt-auto pt-4 flex flex-col gap-1 border-t border-slate-100 mx-1">
            <Link href={`/${locale}/legal/cgu`}
              className="text-[11px] text-slate-400 hover:text-slate-600 transition-colors px-3 py-1">
              {t('nav.cgu')}
            </Link>
            <Link href={`/${locale}/legal/privacy`}
              className="text-[11px] text-slate-400 hover:text-slate-600 transition-colors px-3 py-1">
              {t('nav.privacy')}
            </Link>
          </div>

        </aside>

        {/* Sidebar tablette */}
        <aside className="hidden sm:flex lg:hidden w-[60px] shrink-0 flex-col items-center py-5 gap-1 border-r border-white/50"
          style={{ background: 'rgba(255,255,255,0.65)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}>
          <div className="flex flex-col items-center gap-1 w-full px-2.5">
            <NavIconItem href="/my-events"                    icon={Icons.myEvents}     iconColor="#185FA5" label={t('nav.myEvents')}    active={isActive('/my-events')} />
            <NavIconItem href={participantsHref ?? '/groups'} icon={Icons.participants} iconColor="#7F77DD" label={t('nav.participants')} active={!!participantsHref && isActive(participantsHref)} />
            <NavIconItem href={teesheetHref ?? '/groups'}     icon={Icons.teesheet}     iconColor="#1D9E75" label={t('nav.teesheet')}     active={!!teesheetHref && isActive(teesheetHref)} />
            <NavIconItem href="/scorecard"                    icon={Icons.scorecard}    iconColor="#D85A30" label={t('nav.scorecard')}    active={isActive('/scorecard')} />
            <NavIconItem href="/promotions"                   icon={Icons.promotions}   iconColor="#D4537E" label={t('nav.promotions')}   active={isActive('/promotions')} />
            <NavIconItem href="/distance"                  icon={Icons.distance}       iconColor="#1D9E75" label={t('nav.distance')}    active={isActive('/distance')} />
          </div>
          <div className="w-8 h-px bg-slate-100 my-2" />
          <div className="flex flex-col items-center gap-1 w-full px-2.5">
            <NavIconItem href={groupsHref}                    icon={Icons.groups}         iconColor="#7F77DD" label={t('nav.groups')}         active={isGroupsActive} />
            <NavIconItem href={eventsHref}                    icon={Icons.events}         iconColor="#185FA5" label={t('nav.events')}         active={eventsListActive} />
            <NavIconItem href={invitationsHref ?? '/groups'}  icon={Icons.invitations}    iconColor="#0C447C" label={t('nav.invitations')}    active={!!invitationsHref && isActive(invitationsHref)} />
            <NavIconItem href={paymentsHref ?? '/groups'}     icon={Icons.payments}       iconColor="#3B6D11" label={t('nav.payments')}       active={!!paymentsHref && isActive(paymentsHref ?? '')} />
            <NavIconItem href={flightsHref ?? '/groups'}      icon={Icons.flights}        iconColor="#EF9F27" label={t('nav.flights')}        active={!!flightsHref && isActive(flightsHref)} />
            <NavIconItem href={resultsHref ?? '/groups'}      icon={Icons.results}        iconColor="#3B6D11" label={t('nav.results')}        active={!!resultsHref && isActive(resultsHref)} />
            <NavIconItem href={clubsHref}                     icon={Icons.clubs}          iconColor="#D4537E" label={t('nav.clubs')}          active={isAnyOwner && isActive('/admin/clubs')} />
            <NavIconItem href={communicationsHref}            icon={Icons.communications} iconColor="#D4537E" label={t('nav.communications')} active={!!gid && isActive(`/groups/${gid}/communications`)} />
            <NavIconItem href={statsHref ?? '/groups'}        icon={Icons.stats}          iconColor="#7F77DD" label={t('nav.stats')}          active={!!statsHref && isActive(statsHref)} />
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto pb-20 sm:pb-0 min-h-0 relative" style={{ background: 'transparent' }}>
          <button onClick={() => setDrawerOpen(v => !v)}
            className="sm:hidden absolute top-3 right-4 z-20 flex items-center justify-center w-9 h-9 rounded-xl transition-all"
            style={{ background: drawerOpen ? 'rgba(24,95,165,0.15)' : 'rgba(255,255,255,0.7)', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)', border: drawerOpen ? '1.5px solid rgba(24,95,165,0.3)' : '1px solid rgba(255,255,255,0.6)', boxShadow: '0 1px 8px rgba(0,0,0,0.10)', color: drawerOpen ? '#185FA5' : '#334155' }}>
            {Icons.hamburger}
          </button>
          {children}
        </main>
      </div>

      {drawerOpen && <div className="sm:hidden fixed inset-0 z-30" onClick={() => setDrawerOpen(false)} />}

      {/* Drawer mobile */}
      <div className={`sm:hidden fixed bottom-[57px] left-0 right-0 z-40 transition-transform duration-300 ease-out ${drawerOpen ? 'translate-y-0' : 'translate-y-full pointer-events-none'}`}
        style={{ background: 'rgba(255,255,255,0.97)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)', borderRadius: '20px 20px 0 0', borderTop: '0.5px solid rgba(0,0,0,0.1)', boxShadow: '0 -8px 32px rgba(0,0,0,0.12)' }}>
        <div className="flex justify-center pt-3 pb-1"><div className="w-10 h-1 rounded-full bg-slate-300" /></div>
        <div className="px-5 py-2 border-b border-slate-100">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('nav.organiser')} 🏆</p>
        </div>
        {organiserDrawerItems.map(item => (
          <Link key={item.label} href={item.href} onClick={() => setDrawerOpen(false)}
            className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50 transition-colors">
            <span style={{ color: item.active ? '#185FA5' : item.color, width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{item.icon}</span>
            <div className="flex flex-col">
              <span style={{ fontSize: 15, fontWeight: item.active ? 700 : 600, color: item.active ? '#185FA5' : '#1e293b' }}>{item.label}</span>
              {(item as any).sublabel && <span style={{ fontSize: 11, color: '#94a3b8', marginTop: 1 }}>{(item as any).sublabel}</span>}
            </div>
            {item.active && <span className="ml-auto w-2 h-2 rounded-full bg-[#185FA5]" />}
          </Link>
        ))}
        <div className="flex gap-4 px-5 py-3 border-t border-slate-100">
          <Link href={`/${locale}/legal/cgu`} onClick={() => setDrawerOpen(false)}
            className="text-[11px] text-slate-400 hover:text-slate-600 transition-colors">
            {t('nav.cgu')}
          </Link>
          <Link href={`/${locale}/legal/privacy`} onClick={() => setDrawerOpen(false)}
            className="text-[11px] text-slate-400 hover:text-slate-600 transition-colors">
            {t('nav.privacy')}
          </Link>
        </div>

        <div style={{ paddingBottom: 'env(safe-area-inset-bottom)', height: 8 }} />
      </div>

      {/* Bottom nav mobile */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-white/40 flex items-stretch"
        style={{ background: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)', paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {[
          { href: '/my-events',                  icon: Icons.myEvents,     label: t('nav.myEvents'),     color: '#185FA5' },
          { href: participantsHref ?? '/groups', icon: Icons.participants,  label: t('nav.participants'),  color: '#7F77DD' },
          { href: teesheetHref ?? '/groups',     icon: Icons.teesheet,      label: t('nav.teesheet'),      color: '#1D9E75' },
          { href: '/scorecard',                  icon: Icons.scorecard,    label: t('nav.scorecard'),    color: '#D85A30' },
          { href: '/distance',                    icon: Icons.distance,     label: t('nav.distance'),     color: '#1D9E75' },
        ].map(item => {
          // « Mes événements » reste allumé sur la page Promotions, qui s'ouvre depuis cette page.
          const active = isActive(item.href) || (item.href === '/my-events' && isActive('/promotions'))
          return (
            <Link key={item.label} href={item.href} onClick={() => setDrawerOpen(false)}
              className="flex flex-col items-center justify-center gap-1 flex-1 py-2.5 relative">
              {active && <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-[3px] bg-[#185FA5] rounded-b-full" />}
              <span style={{ width: 22, height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', color: active ? '#185FA5' : item.color, transform: active ? 'scale(1.1)' : 'scale(1)', transition: 'transform .15s, color .15s' }}>{item.icon}</span>
              <span style={{ fontSize: 10, fontWeight: active ? 700 : 500, color: active ? '#185FA5' : '#334155', lineHeight: 1 }}>{item.label}</span>
            </Link>
          )
        })}
      </nav>
      {deleteModalOpen && (
  <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
    style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
    <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-sm w-full">
      {deleteConfirmed ? (
        <>
          <div className="text-center mb-4">
            <div className="w-12 h-12 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-3">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M5 13l4 4L19 7" stroke="#3B6D11" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <p className="text-[15px] font-bold text-slate-800">{t('nav.deleteRequestSent')}</p>
            <p className="text-[13px] text-slate-500 mt-1">{t('nav.deleteRequestDesc')}</p>
          </div>
          <button onClick={() => { setDeleteModalOpen(false); setDeleteConfirmed(false) }}
            className="w-full py-2.5 rounded-xl bg-slate-100 text-[13px] font-semibold text-slate-700 hover:bg-slate-200 transition-colors">
            {t('nav.close')}
          </button>
        </>
      ) : (
        <>
          <div className="text-center mb-5">
            <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-3">
              <svg width="24" height="24" viewBox="0 0 16 16" fill="none">
                <path d="M2 4h12M5 4V2h6v2M6 7v5M10 7v5M3 4l1 9a1 1 0 001 1h6a1 1 0 001-1l1-9" stroke="#ef4444" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <p className="text-[15px] font-bold text-slate-800">{t('nav.deleteAccountTitle')}</p>
            <p className="text-[13px] text-slate-500 mt-1">{t('nav.deleteAccountDesc')}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setDeleteModalOpen(false)}
              className="flex-1 py-2.5 rounded-xl bg-slate-100 text-[13px] font-semibold text-slate-700 hover:bg-slate-200 transition-colors">
              {t('nav.cancel')}
            </button>
            <button
              disabled={deleteLoading}
              onClick={async () => {
                setDeleteLoading(true)
                try {
                  await fetch('/api/delete-account-request', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: currentUser?.name, email: (await supabase.auth.getUser()).data.user?.email }),
                  })
                  setDeleteConfirmed(true)
                } catch (e) { console.error(e) }
                finally { setDeleteLoading(false) }
              }}
              className="flex-1 py-2.5 rounded-xl bg-red-500 text-[13px] font-semibold text-white hover:bg-red-600 transition-colors disabled:opacity-60">
              {deleteLoading ? '...' : t('nav.confirmDelete')}
            </button>
          </div>
        </>
      )}
    </div>
  </div>
)}
    </div>
  )
}
